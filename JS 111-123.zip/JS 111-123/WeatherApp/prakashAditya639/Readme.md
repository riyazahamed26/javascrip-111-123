<!-- Created a simple weather application using html,css,javascript this can show you the weather of approximately every city
 Weather Api used is of Open Weather
 ApiKey :- "15dd264653ae19e803a868ed7fb3c895" -->