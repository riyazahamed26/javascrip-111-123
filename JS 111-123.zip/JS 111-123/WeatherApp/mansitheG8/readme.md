# simple weather app.

very simple weather app, useful for understanding how APIs work.

 - feel free to make any changes or copy it.
 - used a simple api to create it.
  

## screenshots:

![Screenshot (81)](https://user-images.githubusercontent.com/91800236/193361137-78c5e393-c1e5-40b3-aae0-205fd3c7b71a.png)
![Screenshot (82)](https://user-images.githubusercontent.com/91800236/193361142-6ad30903-ccb9-4b38-8867-361944451515.png)



