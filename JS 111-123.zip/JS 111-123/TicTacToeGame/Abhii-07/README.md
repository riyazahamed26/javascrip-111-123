
# Tic - Tac - Toe

A simple Tic-Tac-Toe web app made with HTML5, CSS3 and JavaScript.


## Demo

https://relaxed-gingersnap-ff29ef.netlify.app

