A website built with HTML,CSS,Javascript
<div align="center">
    <img src="/TicTacToeGame/xeedxendrome/screenshots/z.png" width="400px"</img> 
</div>

<div align="center">
    <img src="/TicTacToeGame/xeedxendrome/screenshots/a.png" width="400px"</img> 
</div>

## How to use
- Players take turn with marking one available box.
- Player which made the straight line first wins

