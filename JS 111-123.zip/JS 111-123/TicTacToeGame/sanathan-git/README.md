# A website built with HTML,CSS,Javascript

## How to use
- click on setting icon set the difficulty level
- select one option
- Player which made the straight line first wins.

## How to start
- open the index.html file in your browser.

